package com.ssafy.SNS201.service;

import com.ssafy.SNS201.dto.Category;

import java.util.List;

public interface CategoryService {
    public List<Category> findCategory();
}
